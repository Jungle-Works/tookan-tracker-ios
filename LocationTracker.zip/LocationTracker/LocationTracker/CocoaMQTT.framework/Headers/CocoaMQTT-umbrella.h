#import <UIKit/UIKit.h>

#import "CocoaMQTT.h"

FOUNDATION_EXPORT double CocoaMQTTVersionNumber;
FOUNDATION_EXPORT const unsigned char CocoaMQTTVersionString[];

