#import <UIKit/UIKit.h>

#import "MSWeakTimer.h"

FOUNDATION_EXPORT double MSWeakTimerVersionNumber;
FOUNDATION_EXPORT const unsigned char MSWeakTimerVersionString[];

