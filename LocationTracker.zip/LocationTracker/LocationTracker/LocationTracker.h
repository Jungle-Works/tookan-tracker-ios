//
//  LocationTracker.h
//  LocationTracker
//
//  Created by cl-macmini-45 on 28/07/16.
//  Copyright © 2016 clicklabs. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for LocationTracker.
FOUNDATION_EXPORT double LocationTrackerVersionNumber;

//! Project version string for LocationTracker.
FOUNDATION_EXPORT const unsigned char LocationTrackerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LocationTracker/PublicHeader.h>


